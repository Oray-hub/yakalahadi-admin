export const firebaseConfig = {
  apiKey: "AIzaSyDL_ZXei88Jo7Xa3Ww4DjjMIPDOiy5j_QM",
  authDomain: "yakalahadi-333ca.firebaseapp.com",
  projectId: "yakalahadi-333ca",
  storageBucket: "yakalahadi-333ca.firebasestorage.app",
  messagingSenderId: "397021820606",
  appId: "1:397021820606:web:a3aa08c2a558b15fef10ef"
}; 